<template>
  <div class="page-header-index-wide page-header-wrapper-grid-content-main">

    
  </div>
</template>

<script>
  import PageLayout from '@/components/page/PageLayout'
  import RouteView from "@/components/layouts/RouteView"
  import { AppPage, ArticlePage, ProjectPage } from './page'
  import { mapGetters } from 'vuex'
  import { getFileAccessHttpUrl } from '@/api/manage';

  export default {
    components: {
      RouteView,
      PageLayout,
      AppPage,
      ArticlePage,
      ProjectPage
    },
    data() {
      
    }
  }
</script>
<style>

  

</style>