<template>
  
</template>

<script>
export default {
  name: "Workplace"
}
</script>

<style>

</style>