<template>
  <div class="all_">
    <header class="aLL_2">
      <!-- Banner -->
      <div class="banner">
        <h1>让物流更智能，让运输更便捷</h1>
        <p>我们致力于提供优质物流管理服务，满足您的各种需求</p>
      </div>
    </header>

      <!-- 系统介绍 -->
      <div class="intro" >
        <h2>智能物流管理系统</h2>
        <p>我们的系统提供全面的物流管理解决方案，包括订单管理、物流追踪、客户管理和数据分析等功能，帮助您提升运输效率、降低成本。</p>
      </div>

  </div>

</template>


<script>
export default {

}
</script>

<style>

.all_{
  /* background-color: #185864; */
  margin-top: 100px;
}
.all_2{
  
}
.wrapper {
  /*渐变的背景色*/
  /*height: 100vh;
  background-image: linear-gradient(to bottom right, #FC466B, #3F5EF8);
  overflow: hidden;*/
  /*背景图*/
  background: url("./img/xrwlbjpt.jpg");
  width: 100%;
  height: 100%;
  position: fixed;
  background-size: 100% 100%;
}

#building {
  /*设置透明度，0为完全透明，1为不透明*/
  opacity: 0.75;
}





/* 导航栏样式 */
nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #ffffff;
  padding: 10px 30px;
  box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
}
.logo {
  font-size: 24px;
  font-weight: bold;
}
.logo img {
  height: 40px;
}
.navigation {
  display: flex;
  list-style-type: none;
  justify-content: space-between;
  align-items: center;
}
.navigation li {
  margin-left: 30px;
}
.navigation li a {
  color: #333333;
  font-size: 16px;
  font-weight: bold;
}

/* Banner样式 */
.banner {
  background-image: url(/path/to/banner-image.jpg);
  background-size: cover;
  height: 600px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
}
.banner h1 {
  font-size: 48px;
  font-weight: bold;
  text-align: center;
  margin-bottom: 40px;
}
.banner p {
  font-size: 24px;
  text-align: center;
  margin-bottom: 40px;
  color: #705252;
}
.banner button {
  background-color: #fe5f55;
  color: white;
  border: none;
  padding: 10px 20px;
  font-size: 20px;
  cursor: pointer;
  transition: all 0.3s ease-in-out;
}
.banner button:hover {
  background-color: #f44435;
}

/* 系统介绍样式 */
.intro {
  margin-top: 50px;
  text-align: center;
}
.intro h2 {
  font-size: 36px;
  font-weight: bold;
  color: #625a58;
  margin-bottom: 40px;
}
.intro p {
  font-size: 24px;
  color: #554a4a;
  margin-bottom: 80px;
}

/* 功能特点样式 */
.features {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin-bottom: 100px;
}
.features h2 {
  font-size: 36px;
  font-weight: bold;
  color: #fe5f55;
  margin-top: 100px;
  margin-bottom: 80px;
}
.features li {
  width: 400px;
  padding: 40px;
  margin: 20px;
  border-radius: 5px;
  box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease-in-out;
}
.features li:hover {
  transform: translateY(-10px);
}
.features h3 {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
}
.features p {
  font-size: 18px;
  margin-bottom: 40px;
}

/* 底部版权信息样式 */
footer {
  background-color: #ffffff;
  padding: 20px 30px;
  text-align: center;
  font-size: 14px;
  color: #999999;
}



</style>