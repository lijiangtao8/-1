<template>
  
</template>

<script>
export default {
  name: "IndexChart"
}
</script>

<style>

</style>