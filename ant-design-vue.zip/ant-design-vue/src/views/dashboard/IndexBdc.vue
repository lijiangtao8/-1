<template>
  
</template>

<script>
export default {
  name: "IndexBdc"
}
</script>

<style>

</style>